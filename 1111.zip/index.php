<?php
session_start();
define('DATA_DIR', 'data');
define('UPLOAD_DIR', 'uploads');
define('BASE_URL', (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/'));
date_default_timezone_set('Asia/Shanghai');

// 初始化检测
if (!file_exists(DATA_DIR . '/config.ini')) {
    if (isset($_POST['init'])) {
        createDirectory(DATA_DIR);
        createDirectory(UPLOAD_DIR);
        saveConfig($_POST['password']);
        header("Location: ./");
        exit;
    }
    showInitUI();
}

// 用户认证
$config = parseConfig();
if (!isAuthenticated()) {
    if (isset($_POST['password']) && password_verify($_POST['password'], $config['password'])) {
        setAuthCookie($config['password']);
        header("Location: ./");
        exit;
    }
    showLoginUI(@$_POST['password']);
}

// 核心功能
handleActions();
if (isset($_FILES['file'])) handleUpload();
if (isset($_POST['content'])) saveNote($_POST);

// 显示界面
showMainUI();

// 功能函数
function getNotes($deleted = false) {
    $notes = [];
    foreach (glob(DATA_DIR . '/*.json') as $file) {
        $note = json_decode(file_get_contents($file), true);
        if ($note['deleted'] == $deleted) {
            $note['file'] = $file;
            $notes[$note['id']] = $note;
        }
    }
    usort($notes, function($a, $b) {
        return $b['time'] <=> $a['time'];
    });
    return $notes;
}

function saveNote($data) {
    $id = $data['id'] ?? uniqid();
    $content = trim($data['content']);
    $note = [
        'id' => $id,
        'content' => processContent($content),
        'time' => time(),
        'deleted' => false,
        'files' => extractFiles($content)
    ];
    file_put_contents(DATA_DIR . "/$id.json", json_encode($note));
    return $id;
}

function processContent($content) {
    return preg_replace_callback('/<a[^>]+href="([^"]+)"/i', function($m) {
        return str_replace($m[1], correctUrl($m[1]), $m[0]);
    }, $content);
}

function correctUrl($url) {
    $parsed = parse_url($url);
    return (isset($parsed['scheme']) ? $parsed['scheme'] . '://' : '') 
        . ($parsed['host'] ?? '') 
        . (isset($parsed['path']) ? rtrim($parsed['path'], '/') : '') 
        . (isset($parsed['query']) ? '?' . $parsed['query'] : '') 
        . (isset($parsed['fragment']) ? '#' . $parsed['fragment'] : '');
}

function extractFiles($content) {
    preg_match_all('/<a[^>]+href="([^"]+)"/i', $content, $matches);
    return $matches[1];
}

function handleActions() {
    $action = $_GET['action'] ?? '';
    $id = $_GET['id'] ?? '';
    $file = DATA_DIR . "/$id.json";
    
    switch ($action) {
        case 'delete':
            if (file_exists($file)) {
                updateNoteStatus($id, true);
            }
            break;
            
        case 'restore':
            if (file_exists($file)) {
                updateNoteStatus($id, false);
            }
            break;
            
        case 'purge':
            if (file_exists($file)) {
                $note = json_decode(file_get_contents($file), true);
                deleteFiles($note['files']);
                unlink($file);
            }
            break;
            
        case 'empty_trash':
            foreach (getNotes(true) as $n) {
                deleteFiles($n['files']);
                unlink($n['file']);
            }
            header("Location: ?trash=1");
            exit;
    }
}

function handleUpload() {
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt'];
    $file = $_FILES['file'];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        http_response_code(500);
        exit;
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExtensions)) {
        http_response_code(400);
        exit;
    }
    
    $filename = uniqid() . ".$ext";
    if (move_uploaded_file($file['tmp_name'], UPLOAD_DIR . "/$filename")) {
        // 修复URL格式，确保没有多余的斜杠
        $url = BASE_URL . '/' . UPLOAD_DIR . '/' . $filename;
        // 确保URL格式正确
        $url = preg_replace('#/+#', '/', $url);
        die(json_encode(['url' => $url]));
    }
    http_response_code(500);
    exit;
}

// 辅助函数
function createDirectory($path) {
    if (!file_exists($path)) {
        mkdir($path, 0755, true);
    }
}

function saveConfig($password) {
    file_put_contents(DATA_DIR . '/config.ini', "password=" . password_hash($password, PASSWORD_DEFAULT));
    file_put_contents(DATA_DIR . '/.htaccess', 'Deny from all');
}

function parseConfig() {
    return parse_ini_file(DATA_DIR . '/config.ini');
}

function isAuthenticated() {
    $config = parseConfig();
    return isset($_COOKIE['auth']) && $_COOKIE['auth'] === $config['password'];
}

function setAuthCookie($password) {
    setcookie('auth', $password, time() + 86400 * 30, '/');
}

function updateNoteStatus($id, $deleted) {
    $file = DATA_DIR . "/$id.json";
    $note = json_decode(file_get_contents($file), true);
    $note['deleted'] = $deleted;
    file_put_contents($file, json_encode($note));
}

function deleteFiles($files) {
    foreach ($files as $f) {
        $path = parse_url($f, PHP_URL_PATH);
        @unlink($_SERVER['DOCUMENT_ROOT'] . $path);
    }
}

// 界面显示函数
function showInitUI() {
    exit('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>系统初始化</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>.container{max-width:400px;margin:50px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.1);}</style>
    </head><body><div class="container"><h3 class="mb-3">系统初始化</h3>
    <form method="post"><input type="password" name="password" class="form-control mb-3" placeholder="设置初始密码" required>
    <button name="init" class="btn btn-primary w-100">初始化</button></form></div></body></html>');
}

function showLoginUI($error) {
    exit('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>登录笔记本</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>.container{max-width:400px;margin:50px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.1);}</style>
    </head><body><div class="container"><h3 class="mb-3">登录笔记本</h3>
    '.($error ? '<div class="alert alert-danger">密码错误！</div>' : '').'
    <form method="post"><input type="password" name="password" class="form-control mb-3" placeholder="输入密码" required>
    <button class="btn btn-primary w-100">登录</button></form></div></body></html>');
}

function showMainUI() {
    $isTrash = isset($_GET['trash']);
    $notes = $isTrash ? getNotes(true) : getNotes();
    $page = max(1, intval($_GET['page'] ?? 1));
    $pageSize = 10;
    $totalPages = ceil(count($notes) / $pageSize);
    $editNote = (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) 
        ? json_decode(file_get_contents(DATA_DIR . "/{$_GET['id']}.json"), true) 
        : null;

    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>'.($isTrash ? '垃圾箱' : '私人笔记本').'</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body{background:#f8f9fa}
        .note-card{background:#fff;border-radius:8px;padding:15px;margin-bottom:15px;box-shadow:0 0 5px rgba(0,0,0,0.1);}
        .editor{min-height:300px;border:1px solid #ddd;padding:15px;margin-bottom:20px;}
        .modal-content,.note-card{border:1px solid rgba(0,0,0,.125);}
        .progress-bar{transition:width 0.3s;}
        .note-card .content {
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style></head><body>
    <div class="container py-4"><div class="row"><div class="col-lg-3 mb-4">'.renderSidebar($isTrash, count(getNotes(true))).'</div>
    <div class="col-lg-9">'.renderEditorModals($editNote).renderNotes($notes, $page, $pageSize, $isTrash, $totalPages).'</div></div></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>'.getEditorScript().'</script></body></html>';
}

function renderSidebar($isTrash, $trashCount) {
    return $isTrash 
        ? '<div class="card shadow-sm"><div class="card-body">
           <a href="./" class="btn btn-primary w-100 mb-2">← 返回</a>
           <button onclick="if(confirm(\'永久删除所有笔记？\'))location.href=\'?trash=1&action=empty_trash\'" class="btn btn-danger w-100">清空垃圾箱</button></div></div>'
        : '<div class="card shadow-sm"><div class="card-body">
           <button class="btn btn-success w-100 mb-3" data-bs-toggle="modal" data-bs-target="#editorModal">✏️ 新建笔记</button>
           <a href="?trash=1" class="btn btn-warning w-100">🗑️ 垃圾箱 ('.$trashCount.')</a></div></div>';
}

function renderEditorModals($editNote) {
    return '<div class="modal fade" id="editorModal"><div class="modal-dialog modal-lg"><div class="modal-content">
        <form method="post"><div class="modal-header"><h5 class="modal-title">新建笔记</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body"><div class="editor" contenteditable></div><input type="hidden" name="content">
        <div class="mt-3"><input type="file" id="fileUpload" hidden><button type="button" class="btn btn-sm btn-outline-secondary" onclick="document.getElementById(\'fileUpload\').click()">上传文件</button>
        <small class="text-muted ms-2">支持拖拽/粘贴文件</small><div class="progress"><div class="progress-bar"></div></div></div></div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button><button type="submit" class="btn btn-primary">保存</button></div>
        </form></div></div></div>

        <div class="modal fade" id="editModal"><div class="modal-dialog modal-lg"><div class="modal-content">
        <form method="post"><input type="hidden" name="id" value="'.($editNote['id'] ?? '').'">
        <div class="modal-header"><h5 class="modal-title">编辑笔记</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body"><div class="editor" contenteditable>'.htmlspecialchars($editNote['content'] ?? '').'</div><input type="hidden" name="content">
        <div class="mt-3"><input type="file" id="editFileUpload" hidden><button type="button" class="btn btn-sm btn-outline-secondary" onclick="document.getElementById(\'editFileUpload\').click()">上传文件</button>
        <small class="text-muted ms-2">支持拖拽/粘贴文件</small><div class="progress"><div class="progress-bar"></div></div></div></div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button><button type="submit" class="btn btn-primary">保存修改</button></div>
        </form></div></div></div>';
}

function renderNotes($notes, $page, $pageSize, $isTrash, $totalPages) {
    $output = '';
    foreach (array_slice($notes, ($page - 1) * $pageSize, $pageSize) as $note) {
        $output .= '<div class="note-card"><div class="d-flex justify-content-between mb-2">
            <small class="text-muted">'.date('Y-m-d H:i', $note['time']).'</small><div>'.getNoteActions($note['id'], $isTrash, $note['content']).'</div></div>
            <div class="content">'.$note['content'].'</div></div>';
    }
    return $output . ($totalPages > 1 ? renderPagination($page, $totalPages, $isTrash) : '');
}

function getNoteActions($id, $isTrash, $content) {
    return $isTrash 
        ? '<a href="?trash=1&action=restore&id='.$id.'" class="btn btn-sm btn-success">恢复</a>
           <a href="?trash=1&action=purge&id='.$id.'" onclick="return confirm(\'永久删除该笔记？\')" class="btn btn-sm btn-danger">删除</a>'
        : '<button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal" 
            data-note-id="'.$id.'" data-note-content="'.htmlspecialchars($content).'">编辑</button>
           <a href="?action=delete&id='.$id.'" onclick="return confirm(\'移到垃圾箱？\')" class="btn btn-sm btn-danger">删除</a>';
}

function renderPagination($page, $totalPages, $isTrash) {
    $links = '';
    for ($i = 1; $i <= $totalPages; $i++) {
        $links .= '<li class="page-item '.($i == $page ? 'active' : '').'">
            <a class="page-link" href="?'.($isTrash ? 'trash=1&' : '').'page='.$i.'">'.$i.'</a></li>';
    }
    return '<nav class="mt-4"><ul class="pagination justify-content-center">'.$links.'</ul></nav>';
}

function getEditorScript() {
    return 'document.addEventListener("DOMContentLoaded",function(){
        function initEditor(editorElem,fileInput,progressBar){
            function uploadHandler(file){
                var fd=new FormData();
                fd.append("file",file);
                var xhr=new XMLHttpRequest();
                xhr.open("POST","");
                xhr.upload.onprogress=function(e){
                    if(e.lengthComputable){
                        var percent=Math.round((e.loaded/e.total)*100);
                        progressBar.style.width=percent+"%";
                    }
                };
                xhr.onload=function(){
                    if(xhr.status===200){
                        var response = JSON.parse(xhr.responseText);
                        var url = response.url;
                        var ext = url.split(".").pop().toLowerCase();
                        
                        if (["jpg", "jpeg", "png", "gif"].includes(ext)) {
                            var img = document.createElement("img");
                            img.src = url;
                            img.alt = file.name;
                            editorElem.appendChild(img);
                        } else {
                            var a = document.createElement("a");
                            a.href = url;
                            a.textContent = file.name;
                            editorElem.appendChild(a);
                        }
                    }
                    progressBar.style.width="0%";
                };
                xhr.send(fd);
            }

            editorElem.addEventListener("paste",function(e){
                var items=Array.prototype.slice.call(e.clipboardData.items);
                var fileItem=items.find(function(i){return i.kind==="file";});
                if(fileItem){
                    e.preventDefault();
                    uploadHandler(fileItem.getAsFile());
                }
            });

            editorElem.addEventListener("dragover",function(e){e.preventDefault();});
            editorElem.addEventListener("drop",function(e){
                e.preventDefault();
                if(e.dataTransfer.files[0]){
                    uploadHandler(e.dataTransfer.files[0]);
                }
            });

            fileInput.addEventListener("change",function(){
                if(this.files[0]){
                    uploadHandler(this.files[0]);
                }
            });
        }

        initEditor(
            document.querySelector("#editorModal .editor"),
            document.getElementById("fileUpload"),
            document.querySelector("#editorModal .progress-bar")
        );
        
        initEditor(
            document.querySelector("#editModal .editor"),
            document.getElementById("editFileUpload"),
            document.querySelector("#editModal .progress-bar")
        );

        document.querySelectorAll("form").forEach(function(form){
            form.addEventListener("submit",function(){
                this.querySelector("input[name=content]").value=this.querySelector(".editor").innerHTML;
            });
        });

        document.getElementById("editModal").addEventListener("show.bs.modal",function(e){
            var button=e.relatedTarget;
            var editor=this.querySelector(".editor");
            editor.innerHTML=button.getAttribute("data-note-content");
            this.querySelector("input[name=id]").value=button.getAttribute("data-note-id");
        });
    });';
}